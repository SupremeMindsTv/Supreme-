package streama

class Report {
  Date dateCreated
  Date lastUpdated

  User createdBy
  String errorCode
  Video video
  Boolean resolved

  static constraints = {

    }


}

