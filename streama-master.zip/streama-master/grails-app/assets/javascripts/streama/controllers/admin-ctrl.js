'use strict';

angular.module('streama').controller('adminCtrl', ['$scope', 'apiService', 'modalService', '$rootScope', function ($scope, apiService, modalService, $rootScope) {

}]);




